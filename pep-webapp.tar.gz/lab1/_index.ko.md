---
title: 실습1. Basic Version
weight: 30
pre: "<b>1. </b>"
---
## Level 1 – Basic Version (All in one)
- **Single Server Implementation**
- **Web Frontend (Apache + PHP)**
- **DB Backend (MYSQL)**
- **Upload to local storage**

## 인스턴스 시작
- 이 랩에서는 단일 서버 위에 웹 애플리케이션 구동에 필요한 웹서버프로그램, 데이터베이스 엔진 그리고 프로그래밍에 필요한 프레임워크를 설치합니다.
- 그리고 개발한 소프트웨어를 배포하여 웹 애플리케이션의 동작을 확인합니다.
- 클라우드 환경에서 단일 서버는 EC2 이고 웹애플리케이션 구동에 필요한 소프트웨어는 Apache, PHP, MySQL 입니다. EC2 인스턴스로 사용할 이미지(AMI)는 `Ubuntu 18.04 AMI` 입니다.

![images/image3.png](images/image3.png)

- EC2 생성에 필요한 단계를 진행하시고 웹서비스와 SSH 접속을 위해 80번과 22번 포트를 열어줍니다.
- EC2 생성이 완료된 후에는 SSH 로 접속하여 MySQL, PHP, Apache 소프트웨어를 설치하고 git 명령을 통해 웹애플리케이션 데모를 위한 개발코드를 다운로드 합니다.

## 소프트웨어 설치
**MySQL 데이터베이스 설치**

`sudo apt-get update`

`sudo apt-get install mysql-server`

`sudo mysql_secure_installation`

👉  type 'Y' for followed question

**Apache 와 PHP 설치**
```
sudo apt-get install apache2 php libapache2-mod-php php-mysql php-curl php-xml php-memcached awscli
```

**Apache 서버 재시작**
```
sudo service apache2 restart
```

**git 설치 및 데모용 웹애플리케이션 다운로드**
```
sudo apt-get install git
cd /var
sudo chown -R ubuntu:ubuntu www
cd /var/www/html
git clone https://github.com/qyjohn/web-demo
cd web-demo
```
**웹서비스용 디렉토리 권한 변경**
```
  sudo chown -R www-data:www-data uploads*
```

**데모용 웹애플리케이션 데이터베이스 생성**
```
sudo mysql
mysql\> CREATE DATABASE web_demo;
mysql\> CREATE USER \'username\'@\'localhost\' IDENTIFIED BY 'password\';
mysql\> GRANT ALL PRIVILEGES ON web_demo.\* TO 'username\'@\'localhost\';
mysql\> quit
```

**데모용 데이터 추가**
- 개발소스코드의 Database 접속을 위한 데이터베이스이름, 사용자 이름과 비밀번호는 각각“web_demo”, “username” 그리고 “password” 입니다. * git 명령으로 다운로드 받은 소스코드 내에는 미리 입력된 web_demo.sql 라는 SQL 문이 포함되어 있으니 이를 import 하여Database에 데이터를 추가합니다.
- git 명령으로 다운로드 받은 소스코드 내에는 미리 입력된 web_demo.sql 라는 SQL 문이 포함되어 있으니 이를 import 하여Database에 데이터를 추가합니다.

```
cd /var/www/html/web-demo
mysql -u username -p web_demo < web_demo.sql
```

**주의사항**
- 만약 데이터베이스이름, 사용자이름, 비밀번호를 변경하고 싶을 경우 vi 에디터를 이용하여config.php 의 내용을 직접 수정하시기 바랍니다.
- PC 에 있는 아무 인터넷브라우저 주소창에 [http://ip-address/web-demo/index.php](http://ip-address/web-demo/index.php) 를 입력하여 데모 애플리케이션을 확인해 보시기 바랍니다.
- 기타 데모 애플리케이션과 관련된 제약 사항은 아래 내용을 참고해주세요.
> You can login with your name, then upload some photos for testing. (You might have noticed that this demo application does not ask you for a password. This is because we would like to make things as simple as possible. Handling user password is a very complicate issue, which is beyond the scope of this entry level tutorial.) Then I suggest that you spend 10 minutes reading through the demo code index.php. The demo code has reasonable documentation in the form of comments, so I am not going to explain the code here.

> Now you are able to get your website working, please upload some more pictures for testing. Upload some small pictures and some big pictures (like 20 MB) to see what happens. Fix any issues you may observe in the tests.
