---
title: 실습2. Load Balanced Solution
weight: 30
pre: "<b>2. </b>"
---
## Level 2 – Scale the application to two or more servers

- **Session sharing issue (ELB or Cache ?)**
- **Shared database issue (RDS)**
- **Shared Storage issue (EFS)**
- **NFS? Single point of failure**

이번 레벨에서는 실습1 의 기본버전을 확장하여 여러 서버에 배포하고자 합니다. 파일 공유를 위해 NFS를 사용할 수도 있지만 (Amazon) EFS를 사용하면 쉽게 파일 공유 서비스를 사용할 수 있습니다.

### STEP 1 - EFS File System 준비

- Go to the EFS Console and create an EFS file system. (Note the DNS Name for EFS file system. You need this value for the next step)
- Terminate the previous EC2 instance because we no longer need it. Launch a new EC2 instance with the Ubuntu 18.04 operating system. SSH into the EC2 instance to install the following software and mount the EFS file system:
    - `sudo apt-get update`
    - `sudo apt-get install nfs-common`
    - `sudo mkdir /efs`
    - `sudo mount -t nfs4 -o nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2 <dns-endpoint-of-your-efs-file-system>:/ /efs`
    - `sudo chown -R ubuntu:ubuntu /efs`
- Then we add the mounting stuff into /etc/fstab to add the following line, so that you do not need to manually mount the EFS file system when the operating system is rebooted.

    ```jsx
    <dns-endpoint-of-your-efs-file-system>:/  /efs    nfs    auto,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2    0       0
    ```

- You can verify the above-mentioned configuration is working using the following commands (run them several times):

    ```jsx
    $ df -h
    $ mount
    $ sudo umount /efs
    $ sudo mount /efs
    ```

### STEP 2 - Install the Apache and PHP

- Run the following commands to install Apache and PHP. Notice that we are not installing the MySQL server this time.
    - `sudo apt-get install apache2 php mysql-client libapache2-mod-php php-mysql php-curl php-xml awscli`
    - `sudo service apache2 start`
- Then we use the EFS file system to store our web application.he EFS file system:

    ```jsx
    $ cd /efs
    $ git clone https://github.com/qyjohn/web-demo
    $ cd web-demo
    $ sudo chown -R www-data:www-data uploads
    $ cd /var/www/html
    $ sudo ln -s /efs/web-demo web-demo
    ```

### **STEP 3 - Launch an RDS Instance**

- Launch an RDS instance running MySQL. When launching the RDS instance (Dev/Test-Mysql,  t2.micro), create a default database named “web_demo”.
- When the RDS instance becomes available. Please make sure that the security group being used on the RDS instance allows inbound connection from your EC2 instance. Then, connect to the RDS instance and create a user for your application.
- This time, when granting privileges, you need to grant external access for the user.

```jsx
mysql -h [endpoint-of-rds-instance] -u <master username> -p

mysql> CREATE DATABASE web_demo;*
mysql> CREATE USER 'username'@'%' IDENTIFIED BY 'password';
mysql> GRANT ALL PRIVILEGES ON web_demo.* TO 'username'@'%';
mysql> quit
```

- Then, use the following command to import the demo data in web_demo.sql to the web_demo database on the RDS database:

```jsx
$ cd /var/www/html/web-demo

$ mysql -h [endpoint-of-rds-instance] -u username -p web_demo < web_demo.sql
```

- Now, modify config.php with the new database server hostname, username, password, and database name.

### **STEP 4 - Create an ElastiCacheMemcached Cluster**

- We use ElastiCache to resolve the session sharing issue between multiple web servers. In the ElastiCache console, launch an ElastiCache cluster with Memcached (just 1 single node is enough) and obtain the endpoint information. Please make sure that the security group being used on the ElastiCache cluster allows inbound connection from your EC2 instance.
- On the web server, configure php.ini to use Memcached for session sharing.
- Edit /etc/php/7.2/apache2/php.ini. Make the following modifications:

    ```jsx
    session.save_handler = memcached

    session.save_path = "[dns-endpoint-to-the-elasticache-node]:11211"
    ```

- Then you need to restart Apache the web server to make the new configuration effective.

    ```jsx
    $ sudo apt-get install php-memcached

    $ sudo service apache2 restart
    ```

- Edit /etc/php/7.2/mods-available/memcached.ini, add the following two lines to support session redundancy. Please note that the value of memcache.session_redundancy equals to the number of cache nodes plus 1 (because of a bug in PHP).

    ```jsx
    memcache.allow_failover=1
    memcache.session_redundancy=2
    ```

- Then you need to restart Apache the web server to make the new configuration effective.

    ```jsx
    $ sudo apt-get install php-memcache

    $ sudo service apache2 restart
    ```

### **STEP 5 - Create an AMI**

Now, create an AMI from the EC2 instance and launch a new EC2 instance with the AMI.

![images/Untitled%206.png](images/Untitled%206.png)

### **STEP 6 - Create an ELB**

Create an Application Load Balancer (ALB) and register the two EC2 instances to the ALB target group. Since we do have Apache running on both web servers, you might want to use HTTP as the ping protocol with 80 as the ping port and “/” as the ping path for the health check parameter for your ELB.

- Create Target Group and Register 2 EC2 instances that you created before
- Create Application Load Balancer and attach target group that you created in 'STEP 1'

### **STEP 7 - Testing**

In your browser, browser to http://elb-endpoint/web-demo/index.php. As you can see, our demo seems to be working on multiple servers. This is so easy!
