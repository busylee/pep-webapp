---
date: 2021-04-25
title: 홈
weight: 20
chapter: true
---

# Scalable Image Upload Web Application

---


이 실습에서는 다양한 AWS 빌딩 블록 (EC2, ELB, RDS, ElastiCache, S3, IAM, CloudWatch, AutoScaling 등)을 사용하여 확장 가능한 웹 애플리케이션을 구축하기 위한 내용을 구성하고 있습니다.

## 주요 서비스 구성요소
- **EC2**
- **ELB**
- **AutoScaling**
- **RDS**
- **Elasticache**
- **S3**
- **IAM**

## 데모 웹페이지
![images/image2.png](images/image2.png)

## 최종 서비스 구성도
![images/image1.png](images/image1.png)

---
<p align="center">
© 2021 Amazon Web Services Korea LLC, All rights reserved.
</p>
