---
title: 실습3. S3 Integration
weight: 30
pre: "<b>3. </b>"
---

## Level 3 – Offload user loads to S3
- **Shared storage**
- **Reduce pressure on web server**
- **Why IAM Roles**

트래픽이 증가할 경우 공유파일시스템을 통한 서비스에는 제한이 있을 수 있습니다. 이 단계에서는 스토리지를 EFS에서 S3로 이동하여 이 문제를 해결합니다.

### STEP 1 - Create S3 bucket

- It is very important that your S3 bucket does not "Block new public ACLs and uploading public objects".
- You can view the configurations of your S3 bucket in the S3 console under "Permissions -> Block public Access Settings (Off)".

### STEP 2 - Moving the storage from EFS to S3 since your we application is limited by the capability of the shared file system

- From one of the EC2 instance, edit /efs/web-demo/config.php and make some minor changes. It does not matter from which EC2 instance you make the changes, because the source files are stored on EFS. The changes will be reflected on both EC2 instances.
- In the following configuration, $s3_bucket is the name of the S3 bucket for share storage, and $s3_baseurl is the URL pointing to the S3 endpoint in the region hosting your S3 bucket. You can also identify this end point in the S3 Console by viewing the properties of an S3 object in the S3 bucket.
- Then we use the EFS file system to store our web application.he EFS file system:

    ```php
    $storage_option = "s3"; // hd or s3
    $s3_region  = “ap-northeast-2";
    $s3_bucket  = "your_s3_bucket_name";
    $s3_prefix  = "uploads";
    $s3_baseurl = "https://s3.ap-northeast-2.amazonaws.com/";
    ```

### **STEP 3 - Attach IAM Role to both EC2 Instances**

- In order for this new setting to work, we need to attach an IAM Role to both EC2 instances. In the IAM Console, create an EC2 Role in the IAM Console, which allows full access to S3 (IAM Console -> Role -> Create Role -> AWS Service -> EC2 -> EC2 -> Amazon S3 Full Access). In the EC2 Console, attach the newly created role to both EC2 instances one by one (Instance -> Actions -> Instance Settings -> Attach/Replace IAM Role).
- In your browser, again browse to [http://elb-endpoint/web-demo/index.php](http://elb-endpoint/web-demo/index.php). At this point you will see missing images, because the previously uploaded images are not available on S3. Newly uploaded images will go to S3 instead of local disk.
The reason we use IAM Role in this tutorial is that with IAM Role you do not need to supply your AWS Access Key and Secret Key in your code. Rather, Your code will assume the role assigned to the EC2 instance, and access the AWS resources that your EC2 instance is allowed to access. Today many people and organizations host their source code on [github.com](http://github.com/) or some other public repositories. By using IAM roles you no longer hard code your AWS credentials in your application, thus eliminating the possibility of leaking your AWS credentials to the public.
