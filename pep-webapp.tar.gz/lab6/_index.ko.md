---
title: 실습6. CDN Integration
weight: 30
pre: "<b>6. </b>"
---

## Level 6 – Use CloudFront for content delivery

- Use CloudFront
- Reduce S3 pressure
- Serve from edge locations

### Create CloudFront distribution

- In this level, we create a CloudFront distribution with your S3 bucket as the origin. This way your static content is served to your end users from the nearest edge locations. In your code, you only need to make the following tiny changes.

    ```php
    $enable_cf  = true;
    $cf_baseurl = “http://xxxxxxxxxxxx.cloudfront.net";
    ```

- Reload the web page in your browser to observe the behavior. Are you able to use CloudFront when the uploaded pictures are stored on disk?

    ![images/Untitled.png](images/Untitled.png)

    ![images/Untitled%201.png](images/Untitled%201.png)
