---
title: 실습4. AutoScaling
weight: 30
pre: "<b>4. </b>"
---

## Level 4 – Dynamically scale the size of your server fleet according to the actual traffic to your web application

- Latency simulation

이번 레벨에서는 임의로 페이지 로딩 시간을 지연 시키는 모의 실험을 통해 scale in/out 동작을 확인합니다.

### 모의 실험 환경 구성

- If you look at /efs/web-demo/config.php, you will find this piece of code:

    `$latency = 0; -> 1 (seconds)`

- And, in /efs/web-demo/index.php, there is a corresponding statement:

     `sleep($latency);`

### 오토스케이링을 이용하여 동적으로 백엔드 서버 수 조정

1. In your EC2 Console, create a launch configuration using the AMI and the IAM Role that we created in LEVEL 3.
2. Create an AutoScaling group using the launch configuration we created in step '1', make sure that the AutoScaling group receives traffic from your ALB target group. Also, change the health check type from EC2 to ELB. (This way, when the ELB determines that an instance is unhealthy, the AutoScaling group will terminate it.) You don’t need to specify any scaling policy at this point.

    ![images/Untitled.png](images/Untitled.png)

3. Click on your ELB and create a new CloudWatch Alarm (ELB -> Monitoring -> Create Alarm) when the average latency (response time) is greater than 1 secs for at least 1 minutes.

    ![images/Untitled%201.png](images/Untitled%201.png)

    ![images/Untitled%202.png](images/Untitled%202.png)

    ![images/Untitled%203.png](images/Untitled%203.png)

4. Click on your AutoScaling group, and create a new simple scaling policy (AutoScaling -> Scaling Policies -> Add policy ), using the CloudWatch Alarm you just created. The auto scaling action can be “add 1 instance and then wait 300 seconds”. This way, if the average latency of your web application exceeds 1 second, AutoScaling will add one more instance to your fleet. You can do the testing by adjusting the $latency value on your existing web servers. Please note the source code resides on your EFS file system, when you make the change from one of your EC2 instances, the change is reflected on all of your EC2 instances.

    ![images/Untitled%204.png](images/Untitled%204.png)

    When you are done with this step, you can play with scaling down by creating another  CloudWatch Alarm and a corresponding auto scaling policy. The CloudWatch alarm will be alarmed when the average latency is smaller than 500 ms for at least 1 minute, and the auto scaling action can be “remove 1 instance and then wait 300 seconds”.

    ![images/Untitled%205.png](images/Untitled%205.png)

- `sudo apt-get install nfs-common`
- `sudo mkdir /efs`
- `sudo mount -t nfs4 -o nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2 <dns-endpoint-of-your-efs-file-system>:/ /efs`
- `sudo chown -R ubuntu:ubuntu /efs`
- Then we add the mounting stuff into /etc/fstab to add the following line, so that you do not need to manually mount the EFS file system when the operating system is rebooted.

    ```jsx
    <dns-endpoint-of-your-efs-file-system>:/  /efs    nfs    auto,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2    0       0
    ```

- You can verify the above-mentioned configuration is working using the following commands (run them several times):

    ```jsx
    $ df -h
    $ mount
    $ sudo umount /efs
    $ sudo mount /efs
    ```

### STEP 2 - Install the Apache and PHP

- Run the following commands to install Apache and PHP. Notice that we are not installing the MySQL server this time.
    - `sudo apt-get install apache2 php mysql-client libapache2-mod-php php-mysql php-curl php-xml awscli`
    - `sudo service apache2 start`
- Then we use the EFS file system to store our web application.he EFS file system:

    ```jsx
    $ cd /efs
    $ git clone https://github.com/qyjohn/web-demo
    $ cd web-demo
    $ sudo chown -R www-data:www-data uploads
    $ cd /var/www/html
    $ sudo ln -s /efs/web-demo web-demo
    ```

### **STEP 3 - Launch an RDS Instance**

- Launch an RDS instance running MySQL. When launching the RDS instance (Dev/Test-Mysql,  t2.micro), create a default database named “web_demo”.
- When the RDS instance becomes available. Please make sure that the security group being used on the RDS instance allows inbound connection from your EC2 instance. Then, connect to the RDS instance and create a user for your application.
- This time, when granting privileges, you need to grant external access for the user.

```jsx
mysql -h [endpoint-of-rds-instance] -u <master username> -p

mysql> CREATE DATABASE web_demo;*
mysql> CREATE USER 'username'@'%' IDENTIFIED BY 'password';
mysql> GRANT ALL PRIVILEGES ON web_demo.* TO 'username'@'%';
mysql> quit
```

- Then, use the following command to import the demo data in web_demo.sql to the web_demo database on the RDS database:

```jsx
$ cd /var/www/html/web-demo

$ mysql -h [endpoint-of-rds-instance] -u username -p web_demo < web_demo.sql
```

- Now, modify config.php with the new database server hostname, username, password, and database name.

### **STEP 4 - Create an ElastiCacheMemcached Cluster**

- We use ElastiCache to resolve the session sharing issue between multiple web servers. In the ElastiCache console, launch an ElastiCache cluster with Memcached (just 1 single node is enough) and obtain the endpoint information. Please make sure that the security group being used on the ElastiCache cluster allows inbound connection from your EC2 instance.
- On the web server, configure php.ini to use Memcached for session sharing.
- Edit /etc/php/7.2/apache2/php.ini. Make the following modifications:

    ```jsx
    session.save_handler = memcached

    session.save_path = "[dns-endpoint-to-the-elasticache-node]:11211"
    ```

- Then you need to restart Apache the web server to make the new configuration effective.

    ```jsx
    $ sudo apt-get install php-memcached

    $ sudo service apache2 restart
    ```

- Edit /etc/php/7.2/mods-available/memcached.ini, add the following two lines to support session redundancy. Please note that the value of memcache.session_redundancy equals to the number of cache nodes plus 1 (because of a bug in PHP).

    ```jsx
    memcache.allow_failover=1
    memcache.session_redundancy=2
    ```

- Then you need to restart Apache the web server to make the new configuration effective.

    ```jsx
    $ sudo apt-get install php-memcache

    $ sudo service apache2 restart
    ```

### **STEP 5 - Create an AMI**

Now, create an AMI from the EC2 instance and launch a new EC2 instance with the AMI.

![images/Untitled%206.png](images/Untitled%206.png)

### **STEP 6 - Create an ELB**

Create an Application Load Balancer (ALB) and register the two EC2 instances to the ALB target group. Since we do have Apache running on both web servers, you might want to use HTTP as the ping protocol with 80 as the ping port and “/” as the ping path for the health check parameter for your ELB.

- Create Target Group and Register 2 EC2 instances that you created before
- Create Application Load Balancer and attach target group that you created in 'STEP 1'

### **STEP 7 - Testing**

In your browser, browser to http://elb-endpoint/web-demo/index.php. As you can see, our demo seems to be working on multiple servers. This is so easy!
